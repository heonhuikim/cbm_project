import os
import sys
import rclpy
import time

from std_msgs.msg import Header
from PyQt5 import QtWidgets, uic
import pyqtgraph as pg
import threading 

UI_FILE_DIR = "ros2_ws/src/ams_gui/ams_gui/dashboard.ui"
home_dir = os.path.expanduser('~')
file_dir = os.path.dirname(__file__)
sys.path.append(os.path.join(home_dir, 'ros2_ws/src/ams_gui/ams_gui/'))
from . analoggaugewidget import *
from . qnode_ams_listener import * 
from . cbm_dashboard_widget import *


rclpy.init()
#t = TestNodeThread()
#t.start()

home_dir = os.path.expanduser('~')
ui_path = os.path.join(home_dir, UI_FILE_DIR)

app = QtWidgets.QApplication(sys.argv)
myWindow = DashboardWidget(ui_path)
myWindow.show()
app.exec_()
    