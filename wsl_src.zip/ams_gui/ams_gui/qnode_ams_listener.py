import sys
import rclpy
from rclpy.node import Node
from std_msgs.msg import Header
from PyQt5.QtCore import QThread, pyqtSignal, pyqtSlot
import time
from cbm_interfaces.msg import AdcRaspi


class QAmsListenerNode(Node, QThread):

    # for Raspi-based DAG installed in seawater pipe line
    _sub_sw_sys_adc = None
    _msg_sw_sys_adc = None
    _signal_sw_sys_adc_received = pyqtSignal(AdcRaspi)

    def __init__(self):

        Node.__init__(self, 'Alarm_and_Monitoring_System')
        QThread.__init__(self)
        self._sub_sw_sys_adc = self.create_subscription(AdcRaspi, '/steam_line/adc_8ch', self.sw_sys_callback, 10)
       
    def __del__(self):
        self.wait()

    def sw_sys_callback(self, msg):
        self._msg_sw_sys_adc = msg
        #self._sw_sys_adc = [msg.ch0, msg.ch1, msg.ch2, msg.ch3, msg.ch4, msg.ch5, msg.ch6, msg.ch7] 
        self._signal_sw_sys_adc_received.emit(self._msg_sw_sys_adc)
        #print("sw:", msg.ch0)

    def run(self):
        while True:
            rclpy.spin_once(self)
            #print("-"*20)
            #self.emit( QtCore.SIGNAL('update(QString)'), "from work thread " + str(i) ) # example 
            time.sleep(0.01)
        self.terminate()

