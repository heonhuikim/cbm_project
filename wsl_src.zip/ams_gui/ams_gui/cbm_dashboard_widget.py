import sys
import os
from PyQt5 import uic
from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtWidgets import *
from analoggaugewidget import *
import numpy as np

import time
import threading
from .qnode_ams_listener import QAmsListenerNode
from queue import Queue

from PyQt5.QtCore import pyqtSignal, pyqtSlot
from sensor_msgs.msg import Image
from cbm_interfaces.msg import AdcRaspi


class DashboardWidget(QtWidgets.QMainWindow):

    _ros_thread = None
    _is_running_ros_thread = None

    def __init__(self, ui_file):

        super(QMainWindow, self).__init__()
        # uic.loadUi('dashboard.ui', self)
        uic.loadUi(ui_file, self)

        self.gauge_ch0.value_min = 0.0
        self.gauge_ch0.value_max = 5.0
        self.gauge_ch0.update_value(0.0)
        
        self.gauge_ch1.value_min = 0.0
        self.gauge_ch1.value_max = 5.0
        self.gauge_ch1.update_value(0.0)

        self.gauge_ch2.value_min = 0.0
        self.gauge_ch2.value_max = 5.0
        self.gauge_ch2.update_value(0.0)

        self.gauge_ch3.value_min = 0.0
        self.gauge_ch3.value_max = 5.0
        self.gauge_ch3.update_value(0.0)

        self.gauge_ch4.value_min = 0.0
        self.gauge_ch4.value_max = 5.0
        self.gauge_ch4.update_value(0.0)

        self.gauge_ch5.value_min = 0.0
        self.gauge_ch5.value_max = 5.0
        self.gauge_ch5.update_value(0.0)

        self.gauge_ch6.value_min = 0.0
        self.gauge_ch6.value_max = 5.0
        self.gauge_ch6.update_value(0.0)

        self.gauge_ch7.value_min = 0.0
        self.gauge_ch7.value_max = 5.0
        self.gauge_ch7.update_value(0.0)

        self.ros_thread = QAmsListenerNode()
        self.ros_thread._signal_sw_sys_adc_received.connect(self.on_sw_sys_adc_received)
        
        self.ros_thread.daemon = True
        self.ros_thread.start()
        
    def on_sw_sys_adc_received(self, adc_msg):
        self.gauge_ch0.update_value(adc_msg.ch0)
        self.gauge_ch1.update_value(adc_msg.ch1)
        self.gauge_ch2.update_value(adc_msg.ch2)
        self.gauge_ch3.update_value(adc_msg.ch3)
        self.gauge_ch4.update_value(adc_msg.ch4)
        self.gauge_ch5.update_value(adc_msg.ch5)
        self.gauge_ch6.update_value(adc_msg.ch6)
        self.gauge_ch7.update_value(adc_msg.ch7) 

    def closeEvent(self, event):
        reply = QMessageBox.question(
            self, "Message",
            "Are you sure you want to quit?", QMessageBox.Close | QMessageBox.Cancel)

        if reply == QMessageBox.Close:
            event.accept()
        else:
            event.ignore()

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    ui_file = 'dashboard.ui'
    myWindow = DashboardWidget(ui_file)
    myWindow.show()
    app.exec_()