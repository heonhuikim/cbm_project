from setuptools import setup
import os 
from glob import glob

package_name = 'ams_gui'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name,'resource'), glob('resource/*.ui')),  # this line is for copy ui file into install folder 
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='hhkim',
    maintainer_email='heonhuikim@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'ams_gui_node = ams_gui.ams_gui_main:main',
        ],
    },
)
